package com.vincentcodes.json.entity;

public class ShirabeJishoApp {
    public ShirabeJishoBookmark Bookmarks;
}

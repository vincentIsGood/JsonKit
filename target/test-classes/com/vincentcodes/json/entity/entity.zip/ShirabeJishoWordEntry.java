package com.vincentcodes.json.entity;

public class ShirabeJishoWordEntry {
    public int type;
    public Object value; // can be int or String (if type 3)

    public String toString(){
        return String.format("Entry{type: %d, value: %s}", type, value);
    }
}

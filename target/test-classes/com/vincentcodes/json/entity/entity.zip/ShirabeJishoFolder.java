package com.vincentcodes.json.entity;

import java.util.List;

public class ShirabeJishoFolder {
    public String name;
    public List<ShirabeJishoWordEntry> list;
}

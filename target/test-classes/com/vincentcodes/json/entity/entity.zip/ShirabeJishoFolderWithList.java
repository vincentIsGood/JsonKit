package com.vincentcodes.json.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

//@JsonInclude(JsonInclude.Include.NON_NULL)
public class ShirabeJishoFolderWithList {
    @JsonIgnore // this annotation is needed for SOME jsons which has no folders property.
    public List<ShirabeJishoFolder> folders;
    public String name;
    public List<ShirabeJishoWordEntry> list;
}

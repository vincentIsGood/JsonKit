package com.vincentcodes.json.entity;

import java.util.List;

public class ShirabeJishoBookmark {
    public List<ShirabeJishoFolderWithList> folders;
}

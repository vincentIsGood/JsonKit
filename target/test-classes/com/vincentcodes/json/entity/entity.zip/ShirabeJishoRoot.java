package com.vincentcodes.json.entity;

public class ShirabeJishoRoot {
    public ShirabeJishoApp ShirabeJisho;
}